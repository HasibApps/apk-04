# YT Downloader v2.0 (Termux build)

## Build
```
pkg install openjdk-17 gradle aapt2   # প্রথমবার
cd YTDownloader
bash build.sh
```
APK: `app/build/outputs/apk/debug/app-debug.apk`

## নতুন ফিচার
- Downloads ট্যাব: Active Queue (Pause / Resume / Retry / Cancel, progress, speed, ETA) + History (search, play, share, delete dialog, swipe-to-delete)
- Settings ট্যাব: Engine mode, yt-dlp updater, default format, concurrent (1-3), Wi-Fi only, embed thumbnail/metadata, subtitles, 4 themes
- Android Share menu তে "YT Downloader" → bottom-sheet popup (অ্যাপ খুলতে হয় না)
- Facebook download fix (নিরাপদ ফাইলনেম, মজবুত format selector, Referer/User-Agent)
- Header: Powered by 亗𝐷𝑒𝑣. 𝐻𝑎𝑠𝑖𝑏 𝐵𝑟𝑜亗

## Flask API মোড
Settings এ আপনার সার্ভারের base URL দিন (যেমন https://your-server.com)। অ্যাপ `POST /video_info` ও `POST /download` ব্যবহার করে।

## টিপ
Facebook/YouTube হঠাৎ কাজ না করলে Settings → "Update yt-dlp Engine" চাপুন।
